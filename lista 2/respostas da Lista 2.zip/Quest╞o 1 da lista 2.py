#Aluno: Deivison rodrigues jordão
#Programa que da a área de um círculo

#Definindo variáveis
raio = 0
pi = 3.14
area = 0

#Entrada de dados
raio = float(input("digite o valor do raio do círculo: "))

#Processamento
area = pi * raio ** 2

#saída de dados
print("A área de um círculo de raio ",raio,"é ",area)
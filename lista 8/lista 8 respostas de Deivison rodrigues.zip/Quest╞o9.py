#Aluno: Deivison rodrigues jordao
#Funcao de soma

#Definicao da funcao

def funcao_soma(N1,N2,N3):
    Soma = N1 + N2 + N3
    print(Soma)

#Entrada

Numero1 = float(input("Digite um argumento(o argumento tem que ser um numero): "))
Numero2 = float(input("Digite um argumento(o argumento tem que ser um numero): "))
Numero3 = float(input("Digite um argumento(o argumento tem que ser um numero): "))

funcao_soma(Numero1,Numero2,Numero3)

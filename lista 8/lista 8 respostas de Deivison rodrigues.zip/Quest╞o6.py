#Aluno: Deivison rodrigues jordao
#Escritor em piramide

#Entrada

string_input = input("Digite sua sua string: ")

#Processamento e saida

for i in range(len(string_input)):
    print(string_input[:i+1])
